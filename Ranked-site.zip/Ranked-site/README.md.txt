# Ranked

Bem-vindo à **Ranked**! 🚀

Este é o seu portal de rankings diários — vote, comente e descubra os top 10 mais amados pelos usuários!

## 🧠 Como editar sem programar
1. Vá até o arquivo `index.html`.
2. Clique em **Edit this file**.
3. Altere textos, listas ou títulos diretamente.
4. Clique em **Commit changes** para salvar.

## 🌍 Como publicar no GitHub Pages
1. Crie um repositório público no GitHub.
2. Faça upload dos arquivos deste projeto.
3. Vá em **Settings → Pages** e ative o site.
4. Seu site estará disponível em: `https://seuusuario.github.io/ranked/`

Feito com ❤️ e criatividade!
